#!/bin/sh
# Copyright (C) zhemed

[ -n "$__IS_MODULE_9_UPGRADE_LOADED" ] && return
__IS_MODULE_9_UPGRADE_LOADED=1

. "$CRASHDIR"/libs/check_dir_avail.sh
. "$CRASHDIR"/libs/check_cpucore.sh
. "$CRASHDIR"/libs/web_get_bin.sh

error_down(){
	echo -e "\033[33m请尝试切换至其他安装源后重新下载！\033[0m"
	sleep 1
}

# 更新/卸载功能菜单
upgrade() {
    while true; do
        echo "-----------------------------------------------"
        [ -z "$version_new" ] && checkupdate
        [ -z "$core_v" ] && core_v=$crashcore
        core_v_new=$(eval echo \$"$crashcore"_v)
        echo -e "\033[30;47m欢迎使用更新功能：\033[0m"
        echo "-----------------------------------------------"
        echo -e "当前目录(\033[32m$CRASHDIR\033[0m)剩余空间：\033[36m$(dir_avail "$CRASHDIR" -h)\033[0m"
        [ "$(dir_avail "$CRASHDIR")" -le 5120 ] && [ "$CRASHDIR" = "$BINDIR" ] && {
            echo -e "\033[33m当前目录剩余空间较低，建议开启小闪存模式！\033[0m"
            sleep 1
        }
        echo "-----------------------------------------------"
        echo -e " 1 更新\033[36m管理脚本    \033[33m$versionsh_l\033[0m > \033[32m$version_new \033[36m$release_type\033[0m"
        echo -e " 2 切换\033[33m内核文件    \033[33m$core_v\033[0m > \033[32m$core_v_new\033[0m"
        echo -e " 3 更新\033[32m数据库文件\033[0m	> \033[32m$GeoIP_v\033[0m"
        echo -e " 4 安装/更新本地\033[33m根证书文件\033[0m"
        echo -e " 5 查看\033[32mPAC\033[0m自动代理配置"
        echo "-----------------------------------------------"
        echo -e " 6 切换\033[36m安装源\033[0m及\033[36m安装版本\033[0m"
        echo -e " 7 \033[32m配置自动更新\033[0m"
        echo -e " 8 \033[31m卸载ShellCrash\033[0m"
        echo "-----------------------------------------------"
        echo -e " 99 \033[36m鸣谢！\033[0m"
        echo "-----------------------------------------------"
        echo -e " 0 返回上级菜单"
        echo "-----------------------------------------------"
        read -p "请输入对应数字 > " num
        case "$num" in
        ""|0)
            break
            ;;
        1)
            setscripts
            ;;
        2)
            setcore
            ;;
        3)
            setgeo
            ;;
        4)
            setcrt
            ;;
        5)
            echo "-----------------------------------------------"
            echo -e "PAC配置链接为：\033[30;47m http://$host:$db_port/ui/pac \033[0m"
            sleep 2
            ;;
        6)
            setserver
            ;;
        7)
            . "$CRASHDIR"/menus/5_task.sh && task_add
            ;;
        8)
            . "$CRASHDIR"/menus/uninstall.sh && uninstall
            ;;
        99)
            echo "-----------------------------------------------"
            echo -e "感谢：\033[32msing-box项目 \033[0m作者\033[36m SagerNet\033[0m 项目地址：\033[32mhttps://github.com/SagerNet/sing-box\033[0m"
            echo -e "感谢：\033[32mDustinWin相关项目 \033[0m作者\033[36m DustinWin\033[0m 作者地址：\033[32mhttps://github.com/DustinWin\033[0m"
            echo "-----------------------------------------------"
            echo -e "特别感谢：\033[36m所有帮助及赞助过此项目的同仁们！\033[0m"
            echo "-----------------------------------------------"
            sleep 2
            ;;
        *)
            errornum
			sleep 1
			break
            ;;
        esac
    done
}

#检查更新
checkupdate(){
	echo -ne "\033[32m正在检查更新！\033[0m\r"
	get_bin "$TMPDIR"/version_new bin/version echooff
	if [ "$?" = "0" ];then
		. "$TMPDIR"/version_new 2>/dev/null
		version_new=$versionsh
	else
		echo -e "\033[31m检查更新失败！请尝试切换其他安装源！\033[0m"
		setserver
		[ "$checkupdate" = false ] || checkupdate
	fi
	rm -rf "$TMPDIR"/version_new
}

#更新脚本
getscripts(){ 
	get_bin "$TMPDIR"/ShellCrash.tar.gz ShellCrash.tar.gz
	if [ "$?" != "0" ];then
		echo -e "\033[33m文件下载失败！\033[0m"
		error_down
	else
		"$CRASHDIR"/start.sh stop 2>/dev/null
		#解压
		echo "-----------------------------------------------"
		echo "开始解压文件！"
		mkdir -p "$CRASHDIR" > /dev/null
		tar -zxf "$TMPDIR/ShellCrash.tar.gz" ${tar_para} -C "$CRASHDIR"/
		if [ $? -ne 0 ];then
			echo -e "\033[33m文件解压失败！\033[0m"
			error_down
		else
			. "$CRASHDIR"/init.sh >/dev/null
			echo "$release_type" | grep -qE '^[0-9]' && setconfig userguide  #回退时重新新手引导
			echo -e "\033[32m脚本更新成功！\033[0m"
		fi
	fi
	rm -rf "$TMPDIR"/ShellCrash.tar.gz
	exit
}
setscripts(){
	echo "-----------------------------------------------"
	echo -e "当前脚本版本为：\033[33m $versionsh_l \033[0m"
	echo -e "最新脚本版本为：\033[32m $version_new \033[0m"
	echo -e "注意更新时会停止服务！"
	echo "-----------------------------------------------"
	read -p "是否更新脚本？[1/0] > " res
	if [ "$res" = '1' ]; then
		#下载更新
		getscripts
		#提示
		echo "-----------------------------------------------"
		echo -e "\033[32m管理脚本更新成功!\033[0m"
		echo "-----------------------------------------------"
		exit;
	fi
}

#更新内核
setcpucore(){ #手动设置内核架构
	cpucore_list="armv5 armv7 arm64 386 amd64 mipsle-softfloat mipsle-hardfloat mips-softfloat"
	echo "-----------------------------------------------"
	echo -e "\033[31m仅适合脚本无法正确识别核心或核心无法正常运行时使用！\033[0m"
	echo -e "当前可供在线下载的处理器架构为："
	echo $cpucore_list | awk -F " " '{for(i=1;i<=NF;i++) {print i" "$i }}'
	echo "-----------------------------------------------"
	read -p "请输入对应数字 > " num
	[ -n "$num" ] && setcpucore=$(echo $cpucore_list | awk '{print $"'"$num"'"}' )
	if [ -z "$setcpucore" ];then
		echo -e "\033[31m请输入正确的处理器架构！\033[0m"
		sleep 1
		cpucore=""
	else
		cpucore=$setcpucore
		setconfig cpucore $cpucore
	fi
}
setcoretype(){ #自定义内核固定为sing-box类型
	crashcore=singbox
}
getcore(){ #下载内核文件
	. "$CRASHDIR"/libs/core_tools.sh #调用下载工具
	crashcore=singbox
	[ -z "$cpucore" ] && check_cpucore
	#获取在线内核文件
	echo "-----------------------------------------------"
	echo "正在在线获取$crashcore核心文件……"
	core_webget 
	case "$?" in
	0)
		echo -e "\033[32m$crashcore核心下载成功！\033[0m"
		sleep 1
	;;
	1)
		echo -e "\033[31m核心文件下载失败！\033[0m"
		[ -z "$custcorelink" ] && error_down
	;;
	*)
		echo -e "\033[31m核心文件下载成功但校验失败！请尝试手动指定CPU版本\033[0m"
		rm -rf ${TMPDIR}/core_new
		rm -rf ${TMPDIR}/core_new.tar.gz
		setcpucore
	;;
	esac
}
setcustcore(){ #自定义内核
	[ -z "$cpucore" ] && check_cpucore
	echo "-----------------------------------------------"
	echo -e "\033[36m内置内核由本项目托管维护；自定义内核源自互联网，致谢各位开发者！\033[0m"
	echo -e "\033[33m自定义内核未经过完整适配，使用出现问题请自行解决！\033[0m"
	echo -e "\033[31m自定义内核已适配定时任务，但不支持小闪存模式！\033[0m"
	echo -e "\033[32m如遇到网络错误请先启动ShellCrash服务！\033[0m"
	[ -n "$custcore" ] && {
	echo "-----------------------------------------------"
	echo -e "当前内核为：\033[36m$custcore\033[0m"
	}
	echo "-----------------------------------------------"
	echo -e "\033[33m请选择需要使用的核心！\033[0m"
	echo -e "1 \033[36mSingBox\033[32m内置内核 \033[0m(1.13.18 本项目托管)"
	echo -e "2 \033[33m自定义内核链接 \033[0m"
	echo "-----------------------------------------------"
	echo -e " 0 返回上级菜单"
	read -p "请输入对应数字 > " num
	case "$num" in
	1)
		crashcore=singbox
		custcorelink=''
		getcore
	;;
	2)
		read -p "请输入自定义内核的链接地址(必须是以.tar.gz、.upx或.gz结尾的压缩文件) > " link
		[ -n "$link" ] && custcorelink="$link"
		setcoretype
		getcore
	;;
	*)
	;;
	esac
}

# 内核选择菜单
setcore() {
    while true; do
        # 获取核心及版本信息
        crashcore=singbox
        zip_type=tar.gz
        [ -n "$custcorelink" ] && custcore="$(echo $custcorelink | sed 's#.*github.com##; s#/releases/download/#@#')"
        ###
        echo "-----------------------------------------------"
        [ -z "$cpucore" ] && check_cpucore
        echo -e "当前内核：\033[42;30m $crashcore \033[47;30m$core_v\033[0m"
        echo -e "当前系统处理器架构：\033[32m $cpucore \033[0m"
        echo -e "\033[33m请选择需要使用的核心版本！\033[0m"
        echo -e "\033[36m如需本地上传，请将.tar.gz文件上传至 /tmp 目录后重新运行crash命令\033[0m"
        echo "-----------------------------------------------"
        echo -e "1 \033[43;30m SingBox \033[0m：	\033[32m官方内核\033[0m"
        echo -e " >>\033[32m$singbox_v  	\033[33mSagerNet 官方 sing-box\033[0m"
        echo -e "  说明文档：	\033[36;4mhttps://sing-box.sagernet.org\033[0m"
        echo "-----------------------------------------------"
        echo -e "2 \033[36m使用自定义内核\033[0m	$custcore"
        echo -e "3 \033[32m更新当前内核\033[0m"
        echo "-----------------------------------------------"
        echo "9 手动指定处理器架构"
        echo "-----------------------------------------------"
        echo "0 返回上级菜单"
        read -p "请输入对应数字 > " num
        case "$num" in
        "" | 0)
            break
            ;;
        1)
            crashcore=singbox
            custcorelink=''
            getcore
            break
            ;;
        2)
            setcustcore
            ;;
        3)
            getcore
            break
            ;;
        9)
            setcpucore
            break
            ;;
        *)
            errornum
            sleep 1
            break
            ;;
        esac
    done
}

#数据库
getgeo(){ #下载Geo文件
	#生成链接
	echo "-----------------------------------------------"
	echo "正在从服务器获取数据库文件…………"
	get_bin "$TMPDIR"/${geoname} bin/geodata/$geotype
	if [ "$?" = "1" ];then
		echo "-----------------------------------------------"
		echo -e "\033[31m文件下载失败！\033[0m"
		error_down
	else
		echo "$geoname" | grep -Eq '.mrs|.srs|.tar.gz' && {
			geofile='ruleset/'
			[ ! -d "$BINDIR"/ruleset ] && mkdir -p "$BINDIR"/ruleset
		}
		if echo "$geoname" | grep -Eq '.tar.gz';then
			tar -zxf "$TMPDIR"/${geoname} ${tar_para} -C "$BINDIR"/${geofile} > /dev/null
			[ $? -ne 0 ] && echo "文件解压失败！" && rm -rf "$TMPDIR"/${geoname} && exit 1
			rm -rf "$TMPDIR"/${geoname}
		else
			mv -f "$TMPDIR"/${geoname} "$BINDIR"/${geofile}${geoname}
		fi
		echo "-----------------------------------------------"
		echo -e "\033[32m$geotype数据库文件下载成功！\033[0m"
		geo_v="$(echo $geotype | awk -F "." '{print $1}')_v"
		setconfig $geo_v $GeoIP_v
	fi
	sleep 1
}

getcustgeo(){
	echo "-----------------------------------------------"
	echo "正在获取数据库文件…………"
	webget "$TMPDIR"/$geoname $custgeolink
	if [ "$?" = "1" ];then
		echo "-----------------------------------------------"
		echo -e "\033[31m文件下载失败！\033[0m"
		error_down
	else
		echo "$geoname" | grep -Eq '.mrs|.srs' && {
			geofile='ruleset/'
			[ ! -d "$BINDIR"/ruleset ] && mkdir -p "$BINDIR"/ruleset
		}
		mv -f "$TMPDIR"/${geoname} "$BINDIR"/${geofile}${geoname}
		echo "-----------------------------------------------"
		echo -e "\033[32m$geotype数据库文件下载成功！\033[0m"
	fi
	sleep 1
}

checkcustgeo() {
    while true; do
        [ "$api_tag" = "latest" ] && api_url=latest || api_url="tags/$api_tag"
        [ ! -s "$TMPDIR"/geo.list ] && {
            echo -e "\033[32m正在查找可更新的数据库文件！\033[0m"
            webget "$TMPDIR"/github_api https://api.github.com/repos/${project}/releases/${api_url}
            release_tag=$(cat "$TMPDIR"/github_api | grep '"tag_name":' | awk -F '"' '{print $4}')
            cat "$TMPDIR"/github_api | grep "browser_download_url" | grep -oE 'releases/download.*' | grep -oiE 'geosite.*\.dat"$|country.*\.mmdb"$|.*.mrs|.*.srs' | sed 's|.*/||' | sed 's/"//' >"$TMPDIR"/geo.list
            rm -rf "$TMPDIR"/github_api
        }
        if [ -s "$TMPDIR"/geo.list ]; then
            echo -e "请选择需要更新的数据库文件："
            echo "-----------------------------------------------"
            cat "$TMPDIR"/geo.list | awk '{print " "NR" "$1}'
            echo -e " 0 返回上级菜单"
            echo "-----------------------------------------------"
            read -p "请输入对应数字 > " num
            case "$num" in
            "" | 0)
                break
                ;;
            [1-99])
                if [ "$num" -le "$(wc -l <"$TMPDIR"/geo.list)" ]; then
                    geotype=$(sed -n "$num"p "$TMPDIR"/geo.list)
                    [ -n "$(echo $geotype | grep -oiE '.*\.srs')" ] && geoname=$geotype
                    custgeolink=https://github.com/${project}/releases/download/${release_tag}/${geotype}
                    getcustgeo
                else
                    errornum
                    sleep 1
                    break
                fi
                ;;
            *)
                errornum
                sleep 1
                beak
                ;;
            esac
        else
            echo -e "\033[31m查找失败，请尽量在服务启动后再使用本功能！\033[0m"
            sleep 1
        fi
    done
}

# 下载自定义数据库文件
setcustgeo() {
	while true; do
		rm -rf "$TMPDIR"/geo.list
		echo "-----------------------------------------------"
		echo -e "\033[36m此处数据库均源自互联网采集，此处致谢各位开发者！\033[0m"
		echo -e "\033[32m请点击或复制链接前往项目页面查看具体说明！\033[0m"
		echo -e "\033[31m自定义数据库不支持定时任务及小闪存模式！\033[0m"
		echo -e "\033[33m如遇到网络错误请先启动ShellCrash服务！\033[0m"
		echo -e "\033[0m请选择需要更新的数据库项目来源：\033[0m"
		echo "-----------------------------------------------"
		echo -e " 1 \033[36;4mhttps://github.com/DustinWin/ruleset_geodata\033[0m (仅限SingBox-srs)"
		echo "-----------------------------------------------"
		echo -e " 9 \033[33m自定义数据库链接 \033[0m"
		echo -e " 0 返回上级菜单"
		read -p "请输入对应数字 > " num
		case "$num" in
		""|0)
			break
		;;
		1)
			project=DustinWin/ruleset_geodata
			api_tag=sing-box-ruleset
			checkcustgeo
		;;
		9)
			read -p "请输入自定义数据库的链接地址 > " link
			[ -n "$link" ] && custgeolink="$link"
			getgeo
		;;
		*)
			errornum
			sleep 1
			break
		;;
		esac
	done
}
setgeo() {
	while true; do
		. $CFG_PATH > /dev/null
		echo "-----------------------------------------------"
		echo -e "\033[36m请选择需要更新的Geo数据库文件：\033[0m"
		echo -e "在线数据库最新版本(每日同步上游)：\033[32m$GeoIP_v\033[0m"
		echo "-----------------------------------------------"
		echo -e " 1 CN-IP绕过文件(约0.1mb)	\033[33m$china_ip_list_v\033[0m"
		echo -e " 2 CN-IPV6绕过文件(约30kb)	\033[33m$china_ipv6_list_v\033[0m"
		echo "-----------------------------------------------"
		echo -e " 3 \033[32m自定义数据库文件\033[0m"
		echo -e " 4 \033[31m清理数据库文件\033[0m"
		echo " 0 返回上级菜单"
		echo "-----------------------------------------------"
		read -p "请输入对应数字 > " num
		case "$num" in
		""|0)
			break
		;;
		1)
			geotype=china_ip_list.txt
			geoname=cn_ip.txt
			getgeo
		;;
		2)
			geotype=china_ipv6_list.txt
			geoname=cn_ipv6.txt
			getgeo
		;;
		3)
			setcustgeo
		;;
		4)
			echo "-----------------------------------------------"
			echo -e "\033[33m这将清理$CRASHDIR目录及/ruleset目录下所有数据库文件！\033[0m"
			echo -e "\033[36m清理后启动服务即可自动下载所需文件~\033[0m"
			echo "-----------------------------------------------"
			read -p "确认清理？[1/0] > " res
			[ "$res" = '1' ] && {
				for file in cn_ip.txt cn_ipv6.txt geoip.db geosite.db;do
					rm -rf $CRASHDIR/$file
				done
				for var in china_ip_list_v china_ipv6_list_v geoip_cn_v geosite_cn_v srs_geoip_cn_v srs_geosite_cn_v srs_v;do
					setconfig $var
				done
				rm -rf $CRASHDIR/ruleset/*
				echo -e "\033[33m所有数据库文件均已清理！\033[0m"
				sleep 1
			}
		;;
		*)
			errornum
			sleep 1
			break
		;;
	esac
done
}


#根证书
getcrt(){
	echo "-----------------------------------------------"
	echo "正在连接服务器获取安装文件…………"
	get_bin "$TMPDIR"/ca-certificates.crt bin/fix/ca-certificates.crt
	if [ "$?" = "1" ];then
		echo "-----------------------------------------------"
		echo -e "\033[31m文件下载失败！\033[0m"
		error_down
	else
		echo "-----------------------------------------------"
		[ "$systype" = 'mi_snapshot' ] && cp -f "$TMPDIR"/ca-certificates.crt $CRASHDIR/tools #镜像化设备特殊处理
		[ -f $openssldir/certs ] && rm -rf $openssldir/certs #如果certs不是目录而是文件则删除并创建目录
		mkdir -p $openssldir/certs
		mv -f "$TMPDIR"/ca-certificates.crt $crtdir
		webget /dev/null https://baidu.com echooff rediron skipceroff
		if [ "$?" = "1" ];then
			export CURL_CA_BUNDLE=$crtdir
			echo "export CURL_CA_BUNDLE=$crtdir" >> /etc/profile
		fi
		echo -e "\033[32m证书安装成功！\033[0m"
		sleep 1
	fi
}
setcrt(){
	openssldir="$(openssl version -d 2>&1 | awk -F '"' '{print $2}')"
	if [ -d "$openssldir/certs/" ];then
 		crtdir="$openssldir/certs/ca-certificates.crt"
   	else
    		crtdir="/etc/ssl/certs/ca-certificates.crt"
 	fi
	if [ -n "$openssldir" ];then
		echo "-----------------------------------------------"
		echo -e "\033[36m安装/更新本地根证书文件(ca-certificates.crt)\033[0m"
		echo -e "\033[33m用于解决证书校验错误，x509报错等问题\033[0m"
		echo -e "\033[31m无上述问题的设备请勿使用！\033[0m"
		echo "-----------------------------------------------"
		[ -f "$crtdir" ] && echo -e "\033[33m检测到系统已经存在根证书文件($crtdir)了！\033[0m\n-----------------------------------------------"
		read -p "是否覆盖更新？(1/0) > " res

		if [ -z "$res" ];then
			errornum
		elif [ "$res" = '0' ]; then
			i=
		elif [ "$res" = '1' ]; then
			getcrt
		else
			errornum
		fi
	else
		echo "-----------------------------------------------"
		echo -e "\033[33m设备可能尚未安装openssl，无法安装证书文件！\033[0m"
		sleep 1
	fi
}

# 写入配置文件
saveserver() {
	setconfig update_url "'$update_url'"
	setconfig url_id $url_id
	setconfig release_type $release_type
	version_new=''
	echo "-----------------------------------------------"
	echo -e "\033[32m源地址切换成功！\033[0m"
}

# 安装源
setserver() {
	while true; do
		[ -z "$release_type" ] && release_name=未指定
		[ -n "$release_type" ] && release_name="$release_type(回退)"
		[ "$release_type" = stable ] && release_name=稳定版
		[ "$release_type" = master ] && release_name=公测版
		[ "$release_type" = dev ] && release_name=开发版
		[ -n "$url_id" ] && url_name=$(grep "$url_id" "$CRASHDIR"/configs/servers.list 2>/dev/null | awk '{print $2}') || url_name="$update_url"
	
		echo "-----------------------------------------------"
		echo -e "\033[30;47m切换ShellCrash版本及更新源地址\033[0m"
		echo -e "当前版本：\033[4;33m$release_name\033[0m 当前源：\033[4;32m$url_name\033[0m"
		echo "-----------------------------------------------"
		grep -E "^1|$release_name" "$CRASHDIR"/configs/servers.list | awk '{print " "NR" "$2}'
		echo "-----------------------------------------------"
		echo -e " a 切换至\033[32m稳定版-stable\033[0m"
		echo -e " b 切换至\033[36m公测版-master\033[0m"
		echo -e " c 切换至\033[33m开发版-dev\033[0m"
		echo "-----------------------------------------------"
		echo -e " d 自定义源地址(用于本地源或自建源)"
		echo -e " e \033[31m版本回退\033[0m"
		echo -e " 0 返回上级菜单"
		echo "-----------------------------------------------"
		read -p "请输入对应字母或数字 > " num
		case "$num" in
		""|0)
			checkupdate=false
			break
		;;
		[1-99])
			url_id_new=$(grep -E "^1|$release_name" "$CRASHDIR"/configs/servers.list | sed -n "$num"p | awk '{print $1}')
			if [ -z "$url_id_new" ];then
				errornum
				sleep 1
				continue
			elif [ "$url_id_new" -ge 200 ];then
				update_url=$(grep -E "^1|$release_name" "$CRASHDIR"/configs/servers.list | sed -n "$num"p | awk '{print $3}')
				url_id=''
				saveserver
				break
			else
				url_id=$url_id_new
				update_url=''
				saveserver
				break
			fi
			unset url_id_new
		;;
		a)
			release_type=stable
			[ -z "$url_id" ] && url_id=101
			saveserver
		;;
		b)
			release_type=master
			[ -z "$url_id" ] && url_id=101
			saveserver
		;;
		c)
			echo "-----------------------------------------------"
			echo -e "\033[33m开发版未经过妥善测试，可能依然存在大量bug！！！\033[0m"
			echo -e "\033[36m如果你没有足够的耐心或者测试经验，切勿使用此版本！\033[0m"
			echo -e "请务必加入我们的讨论组：\033[32;4mhttps://github.com/zhemed/ShellCrash\033[0m"
			read -p "是否依然切换到开发版？(1/0) > " res
			if [ "$res" = 1 ];then
				release_type=dev
				[ -z "$url_id" ] && url_id=101
				saveserver
			fi
		;;
		d)
			echo "-----------------------------------------------"
			read -p "请输入个人源路径 > " update_url
			if [ -z "$update_url" ];then
				echo "-----------------------------------------------"
				echo -e "\033[31m取消输入，返回上级菜单\033[0m"
			else
				url_id=''
				release_type=''
				saveserver
			fi
		;;
		e)
			echo "-----------------------------------------------"
			if [ -n "$url_id" ] && [ "$url_id" -lt 200 ];then
				echo -ne "\033[32m正在获取版本信息！\033[0m\r"
				. "$CRASHDIR"/libs/web_get_lite.sh
				web_get_lite https://github.com/zhemed/ShellCrash/tags | grep -o 'releases/tag/.*data'|awk -F '/' '{print $3}'|sed 's/".*//g' > "$TMPDIR"/tags
				if [ "$?" = "0" ];then
					echo -e "\033[31m请选择想要回退至的具体版本：\033[0m"
					cat "$TMPDIR"/tags | awk '{print " "NR" "$1}'
					echo -e " 0 返回上级菜单"
					read -p "请输入对应数字 > " num
					if [ -z "$num" -o "$num" = 0 ]; then
						continue
					elif [ $num -le $(cat "$TMPDIR"/tags 2>/dev/null | awk 'END{print NR}') ]; then
						release_type=$(cat "$TMPDIR"/tags | awk '{print $1}' | sed -n "$num"p)
						update_url=''
						saveserver
					else
						echo "-----------------------------------------------"
						errornum
						sleep 1
						continue
					fi
				else
					echo "-----------------------------------------------"
					echo -e "\033[31m版本回退信息获取失败，请尝试更换其他安装源！\033[0m"
					sleep 1
					continue
				fi
				rm -rf "$TMPDIR"/tags
			else
				echo -e "\033[31m当前源不支持版本回退，请尝试更换其他安装源！\033[0m"
				sleep 1
				continue
			fi
		;;
		*)
			errornum
			sleep 1
			break
		;;
		esac
	done
}
